// Studio keeps experiment admission. The local GUI explicitly selects its
// user-requested review policy; this does not reopen automated experiments.
import { Mastra } from "@mastra/core/mastra";
import { createDispositionConfiguration, interactiveProfile } from "../disposition/runtime.ts";
export const mastra = new Mastra(createDispositionConfiguration(undefined, undefined, { profile: interactiveProfile() }));
